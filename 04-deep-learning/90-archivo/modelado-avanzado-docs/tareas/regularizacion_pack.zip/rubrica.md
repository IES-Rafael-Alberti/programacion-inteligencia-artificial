# 📝 Rúbrica Mini-Actividad Regularización

| Criterio | Puntos |
|----------|--------|
| Implementación modelo base | 2 |
| Aplicación dropout | 2 |
| Aplicación L2 | 2 |
| Data augmentation | 2 |
| Early stopping | 1 |
| Análisis y conclusiones | 1 |

Total: 10 puntos
