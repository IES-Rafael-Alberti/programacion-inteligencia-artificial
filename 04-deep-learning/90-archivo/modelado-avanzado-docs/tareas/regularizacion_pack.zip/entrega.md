# 📦 Entrega - Regularización CNN

## 👥 Equipo
- Nombre equipo:
- Miembros:

## 🧠 Modelo base
Descripción breve

## 🔧 Técnicas aplicadas
- Dropout:
- L2:
- Data Augmentation:
- Early Stopping:

## 📊 Resultados
- Accuracy entrenamiento:
- Accuracy validación:

## 📌 Conclusiones
¿Qué técnica ha sido más efectiva y por qué?
